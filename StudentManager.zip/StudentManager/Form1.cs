﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogisticsManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //https://sosobaba.tistory.com/265   //C# 탭
            DataManager.Load_Sends();
            dataGridView_Sends.DataSource = DataManager.Sends ;
            DataManager.Load_Customers();
            dataGridView_customer.DataSource = DataManager.Customers;

            if(DataManager.Sends.Count > 0)
            {

                textBox_name.Text = DataManager.Sends[0].mName;
                textBox_id.Text = DataManager.Sends[0].mId;
                textBox_weight.Text = DataManager.Sends[0].mWeight.ToString();
                textBox_count.Text = DataManager.Sends[0].mCount.ToString();
            }
            if(DataManager.Customers.Count > 0 )
            {

                textBox_customer_name.Text = DataManager.Customers[0].mCustomerName;
                textBox_customer_code.Text = DataManager.Customers[0].mCustormerCode;
            }
        }

        private void dataGridView_Send_CurrentCellChanged(object sender, EventArgs e)
        {

            try
            {
                // 그리드의 셀이 선택되면 텍스트박스에 글자 지정
                Send Send = dataGridView_Sends.CurrentRow.DataBoundItem as Send;

                textBox_name.Text = Send.mName;
                textBox_id.Text = Send.mId;
                textBox_weight.Text = Send.mWeight.ToString();
                textBox_count.Text = Send.mCount.ToString();
            }
            catch(Exception Except)
            {

            }
        }

        private void dataGridView_major_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                // 그리드의 셀이 선택되면 텍스트박스에 글자 지정
                Customer customer = dataGridView_customer.CurrentRow.DataBoundItem as Customer;
                textBox_customer_name.Text = customer.mCustomerName;
                textBox_customer_code.Text = customer.mCustormerCode;
            }
            catch (Exception Except)
            {

            }
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            if(textBox_name.Text.Trim() != "" && textBox_id.Text.Trim() != "" 
              && textBox_weight.Text.Trim() != "" && textBox_count.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Sends)
                {
                    if(item.mId == textBox_id.Text)
                    {
                        isDuplicate = true; 
                        break;
                    }
                }
                if(isDuplicate)
                {
                    MessageBox.Show("해당 학번의 학생 정보는 이미 존재합니다.");
                }
                else
                {
                    try
                    {
                        Send  temp = new Send();
                        temp.mName = textBox_name.Text;
                        temp.mId = textBox_id.Text;
                        double tempWeight = 0.0;
                        double.TryParse(textBox_weight.Text, out tempWeight);
                        temp.mWeight = tempWeight;
                        temp.mCount = int.Parse(textBox_count.Text);
                        temp.RegDate = DateTime.Now;
                        DataManager.Sends.Add(temp);
                        DataManager.PrintLog($"{textBox_id.Text} 학생 추가 완료");
                        dataGridView_Sends.DataSource = null;
                        dataGridView_Sends.DataSource = DataManager.Sends;
                        DataManager.Save_Sends();

                    }
                    catch (Exception except)
                    {
                        MessageBox.Show(except.Message);
                        DataManager.PrintLog(except.Message);
                        DataManager.PrintLog(except.StackTrace);
                    }
                }
            }
            else
            {
                MessageBox.Show("누락된 학생 정보가 있습니다.");
            }
        }

        private void button_del_Click(object sender, EventArgs e)
        {

            if (textBox_id.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Sends)
                {
                    if (item.mId == textBox_id.Text)
                    {
                        isDuplicate = true;
                        DataManager.Sends.Remove(item);
                        break;
                    }
                }
                if (isDuplicate == false)
                {
                    MessageBox.Show("해당 학생의 정보가 존재하지 않습니다.");
                }
                else
                {

                    try
                    {
                        DataManager.PrintLog($"{textBox_id.Text} 학생 정보 제거 완료");
                        dataGridView_Sends.DataSource = null;
                        dataGridView_Sends.DataSource = DataManager.Sends;
                        DataManager.Save_Sends();

                    }
                    catch (Exception except)
                    {
                        MessageBox.Show(except.Message);
                        DataManager.PrintLog(except.Message);
                        DataManager.PrintLog(except.StackTrace);
                    }
                }
            }
            else
            {
                MessageBox.Show("학번 부분이 공백입니다.");
            }
        }

        private void button_modify_Click(object sender, EventArgs e)
        {
            if (textBox_name.Text.Trim() != "" && textBox_id.Text.Trim() != ""
              && textBox_weight.Text.Trim() != "" && textBox_count.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Sends)
                {
                    if (item.mId == textBox_id.Text)
                    {
                        item.mName = textBox_name.Text;
                        double.TryParse(textBox_weight.Text, out double tempWeight);
                        item.mWeight = tempWeight;
                        int.TryParse(textBox_count.Text, out int tempCount);
                        item.mCount = tempCount;
                        isDuplicate = true;
                        break;
                    }
                }
                if (isDuplicate == false)
                {
                    MessageBox.Show("(수정)해당 학생의 정보가 존재하지 않습니다.");
                }
                else
                {
                    try
                    {
                        DataManager.PrintLog($"{textBox_id.Text} 학생 수정 완료");
                        dataGridView_Sends.DataSource = null;
                        dataGridView_Sends.DataSource = DataManager.Sends;
                        DataManager.Save_Sends();

                    }
                    catch (Exception except)
                    {
                        MessageBox.Show(except.Message);
                        DataManager.PrintLog(except.Message);
                        DataManager.PrintLog(except.StackTrace);
                    }
                }
            }
            else
            {
                MessageBox.Show("(수정)누락된 학생 정보가 있습니다.");
            }
        }

        private void button_select_Click(object sender, EventArgs e)
        {
            if (textBox_id.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Sends)
                {
                    if (item.mId == textBox_id.Text)
                    {
                        string format = $"송장번호가 {item.mId}인 고객님의 정보입니다.{Environment.NewLine}" +
                            $"이름 : {item.mName}" + Environment.NewLine +
                            $"무게 : {item.mWeight}" + Environment.NewLine +
                            $"개수 : {item.mCount}";
                        MessageBox.Show(format);
                        DataManager.PrintLog(format);
                        isDuplicate = true;
                        break;
                    }
                }
                if (isDuplicate == false)
                {
                    MessageBox.Show("해당 물건의 정보가 존재하지 않습니다.");
                }
            }
            else
            {
                MessageBox.Show("(조회)송장번호 부분이 공백입니다.");
            }
        }

        private void button_add_customer_Click(object sender, EventArgs e)
        {
            if (textBox_customer_name.Text.Trim() != "" && textBox_customer_code.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Customers)
                {
                    if (item.mCustormerCode == textBox_customer_code.Text)
                    {
                        isDuplicate = true;
                        break;
                    }
                }
                if (isDuplicate)
                {
                    MessageBox.Show("해당 고객정보는 이미 존재합니다.");
                }
                else
                {
                    try
                    {
                        Customer temp = new Customer();
                        temp.mCustomerName = textBox_customer_name.Text;
                        temp.mCustormerCode = textBox_customer_code.Text;
                        DataManager.Customers.Add(temp);
                        DataManager.PrintLog($"{textBox_customer_code.Text} 고객 추가 완료");
                        dataGridView_customer.DataSource = null;
                        dataGridView_customer.DataSource = DataManager.Customers;
                        DataManager.Save_Customers();

                    }
                    catch (Exception except)
                    {
                        MessageBox.Show(except.Message);
                        DataManager.PrintLog(except.Message);
                        DataManager.PrintLog(except.StackTrace);
                    }
                }
            }
            else
            {
                MessageBox.Show("누락된 배송정보가 있습니다.");
            }
        }

        private void button_modify_customer_Click(object sender, EventArgs e)
        {
            if (textBox_customer_name.Text.Trim() != "" && textBox_customer_code.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Customers)
                {
                    if (item.mCustormerCode == textBox_customer_code.Text)
                    {
                        item.mCustomerName = textBox_customer_name.Text;
                        item.mCustormerCode = textBox_customer_code.Text;
                        isDuplicate = true;
                        break;
                    }
                }
                if (isDuplicate == false)
                {
                    MessageBox.Show("해당 배송정보는 이미 존재합니다.");
                }
                else
                {
                    try
                    {
                        DataManager.PrintLog($"{textBox_customer_code.Text} 배송정보 수정 완료");
                        dataGridView_customer.DataSource = null;
                        dataGridView_customer.DataSource = DataManager.Customers;
                        DataManager.Save_Customers();
                    }
                    catch (Exception except)
                    {
                        MessageBox.Show(except.Message);
                        DataManager.PrintLog(except.Message);
                        DataManager.PrintLog(except.StackTrace);
                    }
                }
            }
            else
            {
                MessageBox.Show("누락된 배송 정보가 있습니다.");
            }
        }

        private void button_del_major_Click(object sender, EventArgs e)
        {

            if (textBox_customer_code.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Customers)
                {
                    if (item.mCustormerCode == textBox_customer_code.Text)
                    {
                        isDuplicate = true;
                        DataManager.Customers.Remove(item);
                        break;
                    }
                }
                if (isDuplicate == false)
                {
                    MessageBox.Show("해당 배송정보가 존재하지 않습니다.");
                }
                else
                {

                    try
                    {
                        DataManager.PrintLog($"{textBox_customer_code.Text} 배송정보 제거 완료");
                        dataGridView_customer.DataSource = null;
                        dataGridView_customer.DataSource = DataManager.Customers;
                        DataManager.Save_Customers();

                    }
                    catch (Exception except)
                    {
                        MessageBox.Show(except.Message);
                        DataManager.PrintLog(except.Message);
                        DataManager.PrintLog(except.StackTrace);
                    }
                }
            }
            else
            {
                MessageBox.Show(" 등기번호 부분이 공백입니다.");
            }
        }

        private void button_select_major_Click(object sender, EventArgs e)
        {
            if (textBox_customer_code.Text.Trim() != "")
            {
                bool isDuplicate = false;
                foreach (var item in DataManager.Customers)
                {
                    if (item.mCustormerCode == textBox_customer_code.Text)
                    {
                        string format = $"등기번호가 {item.mCustormerCode}인 분의 정보입니다.{Environment.NewLine}" +
                            $"고객명 : {item.mCustomerName}";
                        MessageBox.Show(format);
                        DataManager.PrintLog(format);
                        isDuplicate = true;
                        break;
                    }
                }
                if (isDuplicate == false)
                {
                    MessageBox.Show("해당 배송정보가 존재하지 않습니다.");
                }
            }
            else
            {
                MessageBox.Show("(조회)등기번호 부분이 공백입니다.");
            }
        }

    }
}
