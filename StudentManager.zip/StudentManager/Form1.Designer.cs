﻿namespace LogisticsManager
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl_logistics = new System.Windows.Forms.TabControl();
            this.tabPage_student = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_select = new System.Windows.Forms.Button();
            this.textBox_count = new System.Windows.Forms.TextBox();
            this.textBox_weight = new System.Windows.Forms.TextBox();
            this.textBox_id = new System.Windows.Forms.TextBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.button_modify = new System.Windows.Forms.Button();
            this.button_del = new System.Windows.Forms.Button();
            this.button_add = new System.Windows.Forms.Button();
            this.sendBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage_major = new System.Windows.Forms.TabPage();
            this.textBox_customer_code = new System.Windows.Forms.TextBox();
            this.textBox_customer_name = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button_select_customer = new System.Windows.Forms.Button();
            this.button_del_customer = new System.Windows.Forms.Button();
            this.button_modify_customer = new System.Windows.Forms.Button();
            this.button_add_customer = new System.Windows.Forms.Button();
            this.majorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataManagerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView_Sends = new System.Windows.Forms.DataGridView();
            this.dataGridView_customer = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sendBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mCustomerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mCustormerCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabControl_logistics.SuspendLayout();
            this.tabPage_student.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sendBindingSource)).BeginInit();
            this.tabPage_major.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.majorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataManagerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Sends)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_customer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sendBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl_logistics
            // 
            this.tabControl_logistics.Controls.Add(this.tabPage_student);
            this.tabControl_logistics.Controls.Add(this.tabPage_major);
            this.tabControl_logistics.Location = new System.Drawing.Point(0, 0);
            this.tabControl_logistics.Name = "tabControl_logistics";
            this.tabControl_logistics.SelectedIndex = 0;
            this.tabControl_logistics.Size = new System.Drawing.Size(750, 404);
            this.tabControl_logistics.TabIndex = 0;
            // 
            // tabPage_student
            // 
            this.tabPage_student.Controls.Add(this.label7);
            this.tabPage_student.Controls.Add(this.dataGridView_Sends);
            this.tabPage_student.Controls.Add(this.label4);
            this.tabPage_student.Controls.Add(this.label3);
            this.tabPage_student.Controls.Add(this.label2);
            this.tabPage_student.Controls.Add(this.label1);
            this.tabPage_student.Controls.Add(this.button_select);
            this.tabPage_student.Controls.Add(this.textBox_count);
            this.tabPage_student.Controls.Add(this.textBox_weight);
            this.tabPage_student.Controls.Add(this.textBox_id);
            this.tabPage_student.Controls.Add(this.textBox_name);
            this.tabPage_student.Controls.Add(this.button_modify);
            this.tabPage_student.Controls.Add(this.button_del);
            this.tabPage_student.Controls.Add(this.button_add);
            this.tabPage_student.Location = new System.Drawing.Point(4, 22);
            this.tabPage_student.Name = "tabPage_student";
            this.tabPage_student.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_student.Size = new System.Drawing.Size(742, 378);
            this.tabPage_student.TabIndex = 0;
            this.tabPage_student.Text = "고객정보";
            this.tabPage_student.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(8, 320);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "· 개수";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(8, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "· 무게";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(8, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "· 송장번호";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(8, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "· 고객이름";
            // 
            // button_select
            // 
            this.button_select.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_select.Location = new System.Drawing.Point(302, 201);
            this.button_select.Name = "button_select";
            this.button_select.Size = new System.Drawing.Size(75, 23);
            this.button_select.TabIndex = 7;
            this.button_select.Text = "조회";
            this.button_select.UseVisualStyleBackColor = true;
            this.button_select.Click += new System.EventHandler(this.button_select_Click);
            // 
            // textBox_count
            // 
            this.textBox_count.Location = new System.Drawing.Point(86, 317);
            this.textBox_count.Name = "textBox_count";
            this.textBox_count.Size = new System.Drawing.Size(100, 21);
            this.textBox_count.TabIndex = 6;
            // 
            // textBox_weight
            // 
            this.textBox_weight.Location = new System.Drawing.Point(86, 290);
            this.textBox_weight.Name = "textBox_weight";
            this.textBox_weight.Size = new System.Drawing.Size(100, 21);
            this.textBox_weight.TabIndex = 5;
            // 
            // textBox_id
            // 
            this.textBox_id.Location = new System.Drawing.Point(86, 262);
            this.textBox_id.Name = "textBox_id";
            this.textBox_id.Size = new System.Drawing.Size(100, 21);
            this.textBox_id.TabIndex = 6;
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(86, 235);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(100, 21);
            this.textBox_name.TabIndex = 5;
            // 
            // button_modify
            // 
            this.button_modify.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_modify.Location = new System.Drawing.Point(206, 201);
            this.button_modify.Name = "button_modify";
            this.button_modify.Size = new System.Drawing.Size(75, 23);
            this.button_modify.TabIndex = 4;
            this.button_modify.Text = "수정";
            this.button_modify.UseVisualStyleBackColor = true;
            this.button_modify.Click += new System.EventHandler(this.button_modify_Click);
            // 
            // button_del
            // 
            this.button_del.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_del.Location = new System.Drawing.Point(109, 201);
            this.button_del.Name = "button_del";
            this.button_del.Size = new System.Drawing.Size(75, 23);
            this.button_del.TabIndex = 2;
            this.button_del.Text = "삭제";
            this.button_del.UseVisualStyleBackColor = true;
            this.button_del.Click += new System.EventHandler(this.button_del_Click);
            // 
            // button_add
            // 
            this.button_add.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_add.Location = new System.Drawing.Point(9, 201);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(75, 23);
            this.button_add.TabIndex = 1;
            this.button_add.Text = "추가";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // tabPage_major
            // 
            this.tabPage_major.BackColor = System.Drawing.SystemColors.HighlightText;
            this.tabPage_major.Controls.Add(this.label8);
            this.tabPage_major.Controls.Add(this.dataGridView_customer);
            this.tabPage_major.Controls.Add(this.textBox_customer_code);
            this.tabPage_major.Controls.Add(this.textBox_customer_name);
            this.tabPage_major.Controls.Add(this.label6);
            this.tabPage_major.Controls.Add(this.label5);
            this.tabPage_major.Controls.Add(this.button_select_customer);
            this.tabPage_major.Controls.Add(this.button_del_customer);
            this.tabPage_major.Controls.Add(this.button_modify_customer);
            this.tabPage_major.Controls.Add(this.button_add_customer);
            this.tabPage_major.Location = new System.Drawing.Point(4, 22);
            this.tabPage_major.Name = "tabPage_major";
            this.tabPage_major.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_major.Size = new System.Drawing.Size(742, 378);
            this.tabPage_major.TabIndex = 1;
            this.tabPage_major.Text = "배송정보";
            // 
            // textBox_customer_code
            // 
            this.textBox_customer_code.Location = new System.Drawing.Point(104, 272);
            this.textBox_customer_code.Name = "textBox_customer_code";
            this.textBox_customer_code.Size = new System.Drawing.Size(100, 21);
            this.textBox_customer_code.TabIndex = 5;
            // 
            // textBox_customer_name
            // 
            this.textBox_customer_name.Location = new System.Drawing.Point(104, 242);
            this.textBox_customer_name.Name = "textBox_customer_name";
            this.textBox_customer_name.Size = new System.Drawing.Size(100, 21);
            this.textBox_customer_name.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "· 고객등기번호";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "· 지역명";
            // 
            // button_select_customer
            // 
            this.button_select_customer.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_select_customer.Location = new System.Drawing.Point(252, 201);
            this.button_select_customer.Name = "button_select_customer";
            this.button_select_customer.Size = new System.Drawing.Size(75, 23);
            this.button_select_customer.TabIndex = 2;
            this.button_select_customer.Text = "조회";
            this.button_select_customer.UseVisualStyleBackColor = true;
            this.button_select_customer.Click += new System.EventHandler(this.button_select_major_Click);
            // 
            // button_del_customer
            // 
            this.button_del_customer.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_del_customer.Location = new System.Drawing.Point(171, 201);
            this.button_del_customer.Name = "button_del_customer";
            this.button_del_customer.Size = new System.Drawing.Size(75, 23);
            this.button_del_customer.TabIndex = 2;
            this.button_del_customer.Text = "삭제";
            this.button_del_customer.UseVisualStyleBackColor = true;
            this.button_del_customer.Click += new System.EventHandler(this.button_del_major_Click);
            // 
            // button_modify_customer
            // 
            this.button_modify_customer.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_modify_customer.Location = new System.Drawing.Point(90, 201);
            this.button_modify_customer.Name = "button_modify_customer";
            this.button_modify_customer.Size = new System.Drawing.Size(75, 23);
            this.button_modify_customer.TabIndex = 2;
            this.button_modify_customer.Text = "수정";
            this.button_modify_customer.UseVisualStyleBackColor = true;
            this.button_modify_customer.Click += new System.EventHandler(this.button_modify_customer_Click);
            // 
            // button_add_customer
            // 
            this.button_add_customer.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_add_customer.Location = new System.Drawing.Point(9, 201);
            this.button_add_customer.Name = "button_add_customer";
            this.button_add_customer.Size = new System.Drawing.Size(75, 23);
            this.button_add_customer.TabIndex = 2;
            this.button_add_customer.Text = "추가";
            this.button_add_customer.UseVisualStyleBackColor = true;
            this.button_add_customer.Click += new System.EventHandler(this.button_add_customer_Click);
            // 
            // dataGridView_Sends
            // 
            this.dataGridView_Sends.AutoGenerateColumns = false;
            this.dataGridView_Sends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Sends.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dataGridView_Sends.DataSource = this.sendBindingSource1;
            this.dataGridView_Sends.Location = new System.Drawing.Point(7, 7);
            this.dataGridView_Sends.Name = "dataGridView_Sends";
            this.dataGridView_Sends.RowTemplate.Height = 23;
            this.dataGridView_Sends.Size = new System.Drawing.Size(599, 150);
            this.dataGridView_Sends.TabIndex = 9;
            // 
            // dataGridView_customer
            // 
            this.dataGridView_customer.AutoGenerateColumns = false;
            this.dataGridView_customer.BackgroundColor = System.Drawing.SystemColors.WindowFrame;
            this.dataGridView_customer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_customer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mCustomerNameDataGridViewTextBoxColumn,
            this.mCustormerCodeDataGridViewTextBoxColumn});
            this.dataGridView_customer.DataSource = this.customerBindingSource1;
            this.dataGridView_customer.Location = new System.Drawing.Point(11, 16);
            this.dataGridView_customer.Name = "dataGridView_customer";
            this.dataGridView_customer.RowTemplate.Height = 23;
            this.dataGridView_customer.Size = new System.Drawing.Size(360, 150);
            this.dataGridView_customer.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "mName";
            this.dataGridViewTextBoxColumn4.HeaderText = "mName";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "mId";
            this.dataGridViewTextBoxColumn5.HeaderText = "mId";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "mWeight";
            this.dataGridViewTextBoxColumn6.HeaderText = "mWeight";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "mCount";
            this.dataGridViewTextBoxColumn7.HeaderText = "mCount";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "RegDate";
            this.dataGridViewTextBoxColumn8.HeaderText = "RegDate";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // sendBindingSource1
            // 
            this.sendBindingSource1.DataSource = typeof(LogisticsManager.Send);
            // 
            // mCustomerNameDataGridViewTextBoxColumn
            // 
            this.mCustomerNameDataGridViewTextBoxColumn.DataPropertyName = "mCustomerName";
            this.mCustomerNameDataGridViewTextBoxColumn.HeaderText = "mCustomerName";
            this.mCustomerNameDataGridViewTextBoxColumn.Name = "mCustomerNameDataGridViewTextBoxColumn";
            // 
            // mCustormerCodeDataGridViewTextBoxColumn
            // 
            this.mCustormerCodeDataGridViewTextBoxColumn.DataPropertyName = "mCustormerCode";
            this.mCustormerCodeDataGridViewTextBoxColumn.HeaderText = "mCustormerCode";
            this.mCustormerCodeDataGridViewTextBoxColumn.Name = "mCustormerCodeDataGridViewTextBoxColumn";
            // 
            // customerBindingSource1
            // 
            this.customerBindingSource1.DataSource = typeof(LogisticsManager.Customer);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(6, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(241, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "★송장 번호만 치셔도 고객정보가 나옵니다.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(18, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(269, 12);
            this.label8.TabIndex = 11;
            this.label8.Text = "★고객 등기 번호만 치셔도 고객정보가 나옵니다.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 402);
            this.Controls.Add(this.tabControl_logistics);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.tabControl_logistics.ResumeLayout(false);
            this.tabPage_student.ResumeLayout(false);
            this.tabPage_student.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sendBindingSource)).EndInit();
            this.tabPage_major.ResumeLayout(false);
            this.tabPage_major.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.majorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataManagerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Sends)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_customer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sendBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_logistics;
        private System.Windows.Forms.TabPage tabPage_student;
        private System.Windows.Forms.TabPage tabPage_major;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private System.Windows.Forms.Button button_modify;
        private System.Windows.Forms.Button button_del;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.TextBox textBox_count;
        private System.Windows.Forms.TextBox textBox_weight;
        private System.Windows.Forms.TextBox textBox_id;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Button button_select;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn mNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mScoreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mGradeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dataManagerBindingSource;
        private System.Windows.Forms.BindingSource majorBindingSource;
        private System.Windows.Forms.Button button_select_customer;
        private System.Windows.Forms.Button button_del_customer;
        private System.Windows.Forms.Button button_modify_customer;
        private System.Windows.Forms.Button button_add_customer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn mMajorNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mMajorCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox_customer_code;
        private System.Windows.Forms.TextBox textBox_customer_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn mWeightDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mCountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource sendBindingSource;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private System.Windows.Forms.DataGridView dataGridView_Sends;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.BindingSource sendBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView_customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn mCustomerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mCustormerCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource customerBindingSource1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

