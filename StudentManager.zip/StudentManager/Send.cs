﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsManager
{
    class Send
    {
        public string mName { get; set; } //물품 이름
        public string mId { get; set; } //송장번호
        public double mWeight { get; set; } //물품 중량
        public int mCount { get; set; } //물품 무게
        public DateTime RegDate { get; set; } //물품 입고 등록 날짜
    }
}
